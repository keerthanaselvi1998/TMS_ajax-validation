package org.tms.services;
import org.tms.beans.Register;

public interface Registerservice {
	public boolean register(Register r);
}
